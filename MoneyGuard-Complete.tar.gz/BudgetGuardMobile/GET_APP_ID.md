# Get Your App Store Connect ID

## Find Your MoneyGuard App ID

You created the MoneyGuard app in App Store Connect. Now I need the App ID to complete the deployment.

### How to Find It:

1. Go to [App Store Connect](https://appstoreconnect.apple.com/)
2. Sign in with joelascious1@icloud.com
3. Click on your **MoneyGuard** app
4. Look at the URL - it will be something like:
   `https://appstoreconnect.apple.com/apps/1234567890/appstore`
   
   The number (1234567890) is your **App Store Connect ID**

### Alternative Method:
1. In App Store Connect, click **MoneyGuard**
2. Go to **App Information** 
3. Look for **Apple ID** - this is the same number

## Once You Have the ID:

Tell me the App Store Connect ID number, and I'll update the configuration and start the build immediately.

Your ID will look like: **1234567890** (a 10-digit number)