# MoneyGuard Deployment Package

## Download Instructions

1. **Download the MoneyGuard-Deployment.tar.gz file** from this Replit project
2. **Extract it** on your computer
3. **Open Terminal/Command Prompt** and navigate to the extracted folder
4. **Follow the deployment steps below**

## Deployment Commands (Run on Your Computer)

```bash
# Install dependencies
npm install

# Set up iOS credentials (interactive)
npx eas login
npx eas credentials

# Build the app (15-20 minutes)
npx eas build --platform ios --profile production

# Submit to App Store (automatic)
npx eas submit --platform ios --latest
```

## Your App Configuration

**Already configured in the package:**
- App Store Connect ID: 6748765441
- Bundle ID: com.budgetguard.mobile
- Apple ID: joelascious1@icloud.com
- Team ID: AW4XQTS3RZ
- EAS Project: @jcundiff2/moneyguard-mobile

## What's Included

- Complete MoneyGuard React Native app
- All assets and icons
- EAS configuration files
- App Store Connect settings
- Backend API integration

## Your Backend URL

The app connects to: https://5000-workspace-joelcundiff2.4e8d8b0c-cac8-413e-81bd-4a934fb6a8e4-00-30mgr449w240a.picard.replit.dev

## After Deployment

Your MoneyGuard app will appear in App Store Connect ready for review!