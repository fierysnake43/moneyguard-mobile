// Expo environment configuration for MoneyGuard deployment
process.env.EXPO_NO_TELEMETRY = '1';
process.env.EXPO_NO_DOTENV = '1';