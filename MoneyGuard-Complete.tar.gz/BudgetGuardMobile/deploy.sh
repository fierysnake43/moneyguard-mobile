#!/bin/bash

# MoneyGuard - Automated Apple App Store Deployment Script
# This script automates the complete deployment process

echo "🛡️  MoneyGuard - Apple App Store Deployment"
echo "=========================================="
echo ""

# Check if we're in the right directory
if [ ! -f "app.json" ]; then
    echo "❌ Error: app.json not found. Please run this script from the mobile/BudgetGuardMobile directory."
    exit 1
fi

echo "✅ MoneyGuard App Configuration:"
echo "   - App Name: MoneyGuard"
echo "   - Bundle ID: com.budgetguard.mobile"
echo "   - Apple ID: joelascious1@icloud.com"
echo "   - Team ID: AW4XQTS3RZ"
echo "   - App Store Connect ID: 6748765441"
echo ""

# Step 1: Check EAS CLI installation
echo "🔍 Checking EAS CLI installation..."
if ! command -v eas &> /dev/null; then
    echo "📦 Installing EAS CLI..."
    npm install -g @expo/cli eas-cli
fi
echo "✅ EAS CLI ready"
echo ""

# Step 2: EAS Login
echo "🔐 EAS Authentication Required"
echo "Please login with your Expo account:"
echo "   Email: joelascious1@icloud.com (or your Expo account)"
echo ""
eas login
if [ $? -ne 0 ]; then
    echo "❌ EAS login failed. Please check your credentials."
    exit 1
fi
echo "✅ EAS authenticated successfully"
echo ""

# Step 3: Configure EAS Build
echo "⚙️  Configuring EAS build..."
eas build:configure
if [ $? -ne 0 ]; then
    echo "❌ EAS configuration failed."
    exit 1
fi
echo "✅ EAS configured successfully"
echo ""

# Step 4: Verify app.json configuration
echo "🔍 Verifying app configuration..."
echo "   Backend URL: $(grep -o '"apiUrl": "[^"]*"' app.json | cut -d'"' -f4)"
echo "   Bundle ID: $(grep -o '"bundleIdentifier": "[^"]*"' app.json | cut -d'"' -f4)"
echo ""

# Step 5: Build for production
echo "🏗️  Building MoneyGuard for App Store..."
echo "This will take 10-20 minutes..."
eas build --platform ios --profile production
if [ $? -ne 0 ]; then
    echo "❌ Build failed. Please check the error messages above."
    exit 1
fi
echo "✅ Build completed successfully!"
echo ""

# Step 6: Submit to App Store
echo "📤 Submitting to App Store..."
echo "This will upload your app to App Store Connect for review."
read -p "Do you want to submit to App Store now? (y/n): " -n 1 -r
echo ""
if [[ $REPLY =~ ^[Yy]$ ]]; then
    eas submit --platform ios --latest
    if [ $? -ne 0 ]; then
        echo "❌ Submission failed. Please check the error messages above."
        exit 1
    fi
    echo "✅ Successfully submitted to App Store!"
    echo ""
    echo "🎉 MoneyGuard Deployment Complete!"
    echo "=================================="
    echo ""
    echo "Next Steps:"
    echo "1. Check App Store Connect for upload status"
    echo "2. Complete app listing information"
    echo "3. Submit for App Store review"
    echo "4. Your app will be live in 1-3 days after approval!"
    echo ""
    echo "App Store Connect: https://appstoreconnect.apple.com/"
else
    echo "⏸️  Skipping App Store submission."
    echo "You can submit later with: eas submit --platform ios --latest"
fi

echo ""
echo "✅ MoneyGuard is ready for the App Store!"
echo "   Your app connects to: https://5000-workspace-joelcundiff2.4e8d8b0c-cac8-413e-81bd-4a934fb6a8e4-00-30mgr449w240a.picard.replit.dev"
echo "   All features are working and ready for users!"