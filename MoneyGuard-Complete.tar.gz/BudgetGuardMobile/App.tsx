import React, { useState, useEffect } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { StatusBar } from 'expo-status-bar';
import { StyleSheet, View, Text, Animated } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';

// Import screens
import DashboardScreen from './src/screens/DashboardScreen';
import BudgetsScreen from './src/screens/BudgetsScreen';
import TransactionsScreen from './src/screens/TransactionsScreen';
import CalculatorScreen from './src/screens/CalculatorScreen';
import AnalyticsScreen from './src/screens/AnalyticsScreen';
import SplashScreen from './src/components/SplashScreen';

const Tab = createBottomTabNavigator();

export default function App() {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate app initialization
    setTimeout(() => {
      setIsLoading(false);
    }, 3000);
  }, []);

  if (isLoading) {
    return <SplashScreen onComplete={() => setIsLoading(false)} />;
  }

  return (
    <SafeAreaProvider>
      <NavigationContainer>
        <Tab.Navigator
          screenOptions={({ route }) => ({
            tabBarIcon: ({ focused, color, size }) => {
              let iconName: keyof typeof Ionicons.glyphMap;

              if (route.name === 'Dashboard') {
                iconName = focused ? 'wallet' : 'wallet-outline';
              } else if (route.name === 'Budgets') {
                iconName = focused ? 'card' : 'card-outline';
              } else if (route.name === 'Transactions') {
                iconName = focused ? 'receipt' : 'receipt-outline';
              } else if (route.name === 'Calculator') {
                iconName = focused ? 'calculator' : 'calculator-outline';
              } else if (route.name === 'Analytics') {
                iconName = focused ? 'bar-chart' : 'bar-chart-outline';
              } else {
                iconName = 'circle';
              }

              return <Ionicons name={iconName} size={size} color={color} />;
            },
            tabBarActiveTintColor: '#3B82F6',
            tabBarInactiveTintColor: '#6B7280',
            tabBarStyle: {
              backgroundColor: '#FFFFFF',
              borderTopWidth: 1,
              borderTopColor: '#E5E7EB',
              paddingBottom: 5,
              paddingTop: 5,
              height: 65,
            },
            tabBarLabelStyle: {
              fontSize: 12,
              fontWeight: '500',
            },
            headerStyle: {
              backgroundColor: '#FFFFFF',
              elevation: 0,
              shadowOpacity: 0,
              borderBottomWidth: 1,
              borderBottomColor: '#E5E7EB',
            },
            headerTitleStyle: {
              fontSize: 18,
              fontWeight: '600',
              color: '#1F2937',
            },
            headerTitleAlign: 'center',
          })}
        >
          <Tab.Screen 
            name="Dashboard" 
            component={DashboardScreen}
            options={{
              title: 'Dashboard',
              headerLeft: () => (
                <View style={styles.headerLeft}>
                  <Ionicons name="shield" size={24} color="#3B82F6" />
                  <Text style={styles.headerTitle}>MoneyGuard</Text>
                </View>
              ),
              headerTitle: '',
            }}
          />
          <Tab.Screen 
            name="Budgets" 
            component={BudgetsScreen}
            options={{
              title: 'Budgets',
              headerLeft: () => (
                <View style={styles.headerLeft}>
                  <Ionicons name="shield" size={24} color="#3B82F6" />
                  <Text style={styles.headerTitle}>MoneyGuard</Text>
                </View>
              ),
              headerTitle: '',
            }}
          />
          <Tab.Screen 
            name="Transactions" 
            component={TransactionsScreen}
            options={{
              title: 'Transactions',
              headerLeft: () => (
                <View style={styles.headerLeft}>
                  <Ionicons name="shield" size={24} color="#3B82F6" />
                  <Text style={styles.headerTitle}>MoneyGuard</Text>
                </View>
              ),
              headerTitle: '',
            }}
          />
          <Tab.Screen 
            name="Calculator" 
            component={CalculatorScreen}
            options={{
              title: 'Calculator',
              headerLeft: () => (
                <View style={styles.headerLeft}>
                  <Ionicons name="shield" size={24} color="#3B82F6" />
                  <Text style={styles.headerTitle}>MoneyGuard</Text>
                </View>
              ),
              headerTitle: '',
            }}
          />
          <Tab.Screen 
            name="Analytics" 
            component={AnalyticsScreen}
            options={{
              title: 'Analytics',
              headerLeft: () => (
                <View style={styles.headerLeft}>
                  <Ionicons name="shield" size={24} color="#3B82F6" />
                  <Text style={styles.headerTitle}>MoneyGuard</Text>
                </View>
              ),
              headerTitle: '',
            }}
          />
        </Tab.Navigator>
      </NavigationContainer>
      <StatusBar style="dark" />
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    marginLeft: 16,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1F2937',
    marginLeft: 8,
  },
});