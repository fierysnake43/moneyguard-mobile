import Constants from 'expo-constants';

const API_URL = Constants.expoConfig?.extra?.apiUrl || 'http://localhost:5000';

export interface BudgetCategory {
  id: number;
  userId: number;
  name: string;
  description: string;
  limit: string;
  icon: string;
  color: string;
  type: 'Need' | 'Want' | 'Investing';
}

export interface Transaction {
  id: number;
  userId: number;
  amount: string;
  description: string;
  categoryId: number;
  date: string;
  status: 'approved' | 'declined';
}

export interface DashboardData {
  totalBudget: number;
  totalSpent: number;
  remaining: number;
  declinedCount: number;
  monthlyIncome: number;
  incomeAfterBudgets: number;
  incomeAfterExpenses: number;
  totalInvested: number;
  investmentPercentage: number;
  categoryProgress: Array<{
    id: number;
    name: string;
    description: string;
    limit: string;
    icon: string;
    color: string;
    spent: number;
    remaining: number;
    percentage: number;
    status: string;
  }>;
}

export interface UserProfile {
  name: string;
  monthlyIncome?: number;
}

class ApiService {
  private baseURL = API_URL;

  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const url = `${this.baseURL}${endpoint}`;
    
    try {
      const response = await fetch(url, {
        headers: {
          'Content-Type': 'application/json',
          ...options.headers,
        },
        ...options,
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('API request failed:', error);
      throw error;
    }
  }

  // Dashboard
  async getDashboard(): Promise<DashboardData> {
    return this.request<DashboardData>('/api/dashboard');
  }

  // Budget Categories
  async getBudgetCategories(): Promise<BudgetCategory[]> {
    return this.request<BudgetCategory[]>('/api/budget-categories');
  }

  async createBudgetCategory(category: Omit<BudgetCategory, 'id' | 'userId'>): Promise<BudgetCategory> {
    return this.request<BudgetCategory>('/api/budget-categories', {
      method: 'POST',
      body: JSON.stringify(category),
    });
  }

  async updateBudgetCategory(id: number, category: Partial<BudgetCategory>): Promise<BudgetCategory> {
    return this.request<BudgetCategory>(`/api/budget-categories/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(category),
    });
  }

  async deleteBudgetCategory(id: number): Promise<void> {
    return this.request<void>(`/api/budget-categories/${id}`, {
      method: 'DELETE',
    });
  }

  // Transactions
  async getTransactions(): Promise<Transaction[]> {
    return this.request<Transaction[]>('/api/transactions');
  }

  async createTransaction(transaction: Omit<Transaction, 'id' | 'userId' | 'date' | 'status'>): Promise<Transaction> {
    return this.request<Transaction>('/api/transactions', {
      method: 'POST',
      body: JSON.stringify(transaction),
    });
  }

  async deleteTransaction(id: number): Promise<void> {
    return this.request<void>(`/api/transactions/${id}`, {
      method: 'DELETE',
    });
  }

  // User Profile
  async getUserProfile(): Promise<UserProfile> {
    return this.request<UserProfile>('/api/profile');
  }

  async updateUserProfile(profile: UserProfile): Promise<UserProfile> {
    return this.request<UserProfile>('/api/profile', {
      method: 'PUT',
      body: JSON.stringify(profile),
    });
  }

  // Settings
  async getSettings(): Promise<any> {
    return this.request<any>('/api/settings');
  }

  async updateSettings(settings: any): Promise<any> {
    return this.request<any>('/api/settings', {
      method: 'PATCH',
      body: JSON.stringify(settings),
    });
  }
}

export const apiService = new ApiService();