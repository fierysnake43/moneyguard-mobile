import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';

type CalculatorType = 'interest' | 'roth-ira' | 'mortgage' | 'loan';

interface CalculationResults {
  futureValue?: number;
  totalContributions?: number;
  totalInterest?: number;
  monthlyPayment?: number;
  totalAmountPaid?: number;
  monthlyIncome?: number;
}

export default function CalculatorScreen() {
  const [selectedCalculator, setSelectedCalculator] = useState<CalculatorType>('interest');
  const [results, setResults] = useState<CalculationResults | null>(null);

  // Interest Calculator State
  const [interestData, setInterestData] = useState({
    initialInvestment: '',
    monthlyContribution: '',
    interestRate: '',
    investmentLength: '',
  });

  // Roth IRA Calculator State
  const [rothData, setRothData] = useState({
    currentBalance: '',
    annualContribution: '',
    expectedReturn: '',
    currentAge: '',
    retirementAge: '',
  });

  // Mortgage Calculator State
  const [mortgageData, setMortgageData] = useState({
    homePrice: '',
    downPaymentPercent: '',
    loanTerm: '',
    interestRate: '',
  });

  // Loan Calculator State
  const [loanData, setLoanData] = useState({
    loanAmount: '',
    loanTerm: '',
    interestRate: '',
  });

  const calculateInterest = () => {
    const principal = parseFloat(interestData.initialInvestment) || 0;
    const monthlyContrib = parseFloat(interestData.monthlyContribution) || 0;
    const annualRate = parseFloat(interestData.interestRate) / 100 || 0;
    const years = parseFloat(interestData.investmentLength) || 0;

    const monthlyRate = annualRate / 12;
    const totalMonths = years * 12;

    // Future value of initial investment
    const futureValuePrincipal = principal * Math.pow(1 + monthlyRate, totalMonths);

    // Future value of monthly contributions
    let futureValueContributions = 0;
    if (monthlyContrib > 0 && monthlyRate > 0) {
      futureValueContributions = monthlyContrib * (Math.pow(1 + monthlyRate, totalMonths) - 1) / monthlyRate;
    }

    const futureValue = futureValuePrincipal + futureValueContributions;
    const totalContributions = principal + (monthlyContrib * totalMonths);
    const totalInterest = futureValue - totalContributions;

    setResults({
      futureValue,
      totalContributions,
      totalInterest,
    });
  };

  const calculateRothIRA = () => {
    const currentBalance = parseFloat(rothData.currentBalance) || 0;
    const annualContribution = parseFloat(rothData.annualContribution) || 0;
    const expectedReturn = parseFloat(rothData.expectedReturn) / 100 || 0;
    const currentAge = parseFloat(rothData.currentAge) || 0;
    const retirementAge = parseFloat(rothData.retirementAge) || 0;

    const yearsToRetirement = retirementAge - currentAge;

    // Future value of current balance
    const futureValueCurrent = currentBalance * Math.pow(1 + expectedReturn, yearsToRetirement);

    // Future value of annual contributions
    let futureValueContributions = 0;
    if (annualContribution > 0 && yearsToRetirement > 0) {
      futureValueContributions = annualContribution * (Math.pow(1 + expectedReturn, yearsToRetirement) - 1) / expectedReturn;
    }

    const futureValue = futureValueCurrent + futureValueContributions;
    const totalContributions = currentBalance + (annualContribution * yearsToRetirement);
    const totalInterest = futureValue - totalContributions;

    // Estimate monthly income at retirement (4% withdrawal rule)
    const monthlyIncome = (futureValue * 0.04) / 12;

    setResults({
      futureValue,
      totalContributions,
      totalInterest,
      monthlyIncome,
    });
  };

  const calculateMortgage = () => {
    const homePrice = parseFloat(mortgageData.homePrice) || 0;
    const downPaymentPercent = parseFloat(mortgageData.downPaymentPercent) || 0;
    const loanTerm = parseFloat(mortgageData.loanTerm) || 0;
    const interestRate = parseFloat(mortgageData.interestRate) / 100 || 0;

    const downPayment = homePrice * (downPaymentPercent / 100);
    const loanAmount = homePrice - downPayment;
    const monthlyRate = interestRate / 12;
    const totalMonths = loanTerm * 12;

    const monthlyPayment = loanAmount * 
      (monthlyRate * Math.pow(1 + monthlyRate, totalMonths)) / 
      (Math.pow(1 + monthlyRate, totalMonths) - 1);

    const totalAmountPaid = monthlyPayment * totalMonths;
    const totalInterest = totalAmountPaid - loanAmount;

    setResults({
      monthlyPayment,
      totalAmountPaid,
      totalInterest,
    });
  };

  const calculateLoan = () => {
    const loanAmount = parseFloat(loanData.loanAmount) || 0;
    const loanTerm = parseFloat(loanData.loanTerm) || 0;
    const interestRate = parseFloat(loanData.interestRate) / 100 || 0;

    const monthlyRate = interestRate / 12;
    const totalMonths = loanTerm * 12;

    const monthlyPayment = loanAmount * 
      (monthlyRate * Math.pow(1 + monthlyRate, totalMonths)) / 
      (Math.pow(1 + monthlyRate, totalMonths) - 1);

    const totalAmountPaid = monthlyPayment * totalMonths;
    const totalInterest = totalAmountPaid - loanAmount;

    setResults({
      monthlyPayment,
      totalAmountPaid,
      totalInterest,
    });
  };

  const handleCalculate = () => {
    switch (selectedCalculator) {
      case 'interest':
        calculateInterest();
        break;
      case 'roth-ira':
        calculateRothIRA();
        break;
      case 'mortgage':
        calculateMortgage();
        break;
      case 'loan':
        calculateLoan();
        break;
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  const calculatorOptions = [
    { id: 'interest', name: 'Interest Calculator', icon: 'trending-up' },
    { id: 'roth-ira', name: 'Roth IRA Calculator', icon: 'wallet' },
    { id: 'mortgage', name: 'Mortgage Calculator', icon: 'home' },
    { id: 'loan', name: 'Loan Calculator', icon: 'card' },
  ];

  const renderCalculatorSelector = () => (
    <View style={styles.selectorContainer}>
      <Text style={styles.selectorTitle}>Select Calculator</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.selectorScroll}>
        {calculatorOptions.map((option) => (
          <TouchableOpacity
            key={option.id}
            style={[
              styles.selectorOption,
              selectedCalculator === option.id && styles.selectorOptionSelected,
            ]}
            onPress={() => {
              setSelectedCalculator(option.id as CalculatorType);
              setResults(null);
            }}
          >
            <Ionicons
              name={option.icon as any}
              size={24}
              color={selectedCalculator === option.id ? '#FFFFFF' : '#6B7280'}
            />
            <Text
              style={[
                styles.selectorOptionText,
                selectedCalculator === option.id && styles.selectorOptionTextSelected,
              ]}
            >
              {option.name}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );

  const renderInterestCalculator = () => (
    <View style={styles.calculatorContainer}>
      <Text style={styles.calculatorTitle}>Compound Interest Calculator</Text>
      <View style={styles.inputRow}>
        <View style={styles.inputContainer}>
          <Text style={styles.inputLabel}>Initial Investment ($)</Text>
          <TextInput
            style={styles.textInput}
            value={interestData.initialInvestment}
            onChangeText={(text) => setInterestData({ ...interestData, initialInvestment: text })}
            keyboardType="numeric"
            placeholder="0"
          />
        </View>
        <View style={styles.inputContainer}>
          <Text style={styles.inputLabel}>Monthly Contribution ($)</Text>
          <TextInput
            style={styles.textInput}
            value={interestData.monthlyContribution}
            onChangeText={(text) => setInterestData({ ...interestData, monthlyContribution: text })}
            keyboardType="numeric"
            placeholder="0"
          />
        </View>
      </View>
      <View style={styles.inputRow}>
        <View style={styles.inputContainer}>
          <Text style={styles.inputLabel}>Interest Rate (%)</Text>
          <TextInput
            style={styles.textInput}
            value={interestData.interestRate}
            onChangeText={(text) => setInterestData({ ...interestData, interestRate: text })}
            keyboardType="numeric"
            placeholder="0"
          />
        </View>
        <View style={styles.inputContainer}>
          <Text style={styles.inputLabel}>Investment Length (years)</Text>
          <TextInput
            style={styles.textInput}
            value={interestData.investmentLength}
            onChangeText={(text) => setInterestData({ ...interestData, investmentLength: text })}
            keyboardType="numeric"
            placeholder="0"
          />
        </View>
      </View>
    </View>
  );

  const renderRothIRACalculator = () => (
    <View style={styles.calculatorContainer}>
      <Text style={styles.calculatorTitle}>Roth IRA Calculator</Text>
      <View style={styles.inputRow}>
        <View style={styles.inputContainer}>
          <Text style={styles.inputLabel}>Current Balance ($)</Text>
          <TextInput
            style={styles.textInput}
            value={rothData.currentBalance}
            onChangeText={(text) => setRothData({ ...rothData, currentBalance: text })}
            keyboardType="numeric"
            placeholder="0"
          />
        </View>
        <View style={styles.inputContainer}>
          <Text style={styles.inputLabel}>Annual Contribution ($)</Text>
          <TextInput
            style={styles.textInput}
            value={rothData.annualContribution}
            onChangeText={(text) => setRothData({ ...rothData, annualContribution: text })}
            keyboardType="numeric"
            placeholder="0"
          />
        </View>
      </View>
      <View style={styles.inputRow}>
        <View style={styles.inputContainer}>
          <Text style={styles.inputLabel}>Expected Return (%)</Text>
          <TextInput
            style={styles.textInput}
            value={rothData.expectedReturn}
            onChangeText={(text) => setRothData({ ...rothData, expectedReturn: text })}
            keyboardType="numeric"
            placeholder="0"
          />
        </View>
        <View style={styles.inputContainer}>
          <Text style={styles.inputLabel}>Current Age</Text>
          <TextInput
            style={styles.textInput}
            value={rothData.currentAge}
            onChangeText={(text) => setRothData({ ...rothData, currentAge: text })}
            keyboardType="numeric"
            placeholder="0"
          />
        </View>
      </View>
      <View style={styles.inputContainer}>
        <Text style={styles.inputLabel}>Retirement Age</Text>
        <TextInput
          style={styles.textInput}
          value={rothData.retirementAge}
          onChangeText={(text) => setRothData({ ...rothData, retirementAge: text })}
          keyboardType="numeric"
          placeholder="0"
        />
      </View>
    </View>
  );

  const renderMortgageCalculator = () => (
    <View style={styles.calculatorContainer}>
      <Text style={styles.calculatorTitle}>Mortgage Calculator</Text>
      <View style={styles.inputRow}>
        <View style={styles.inputContainer}>
          <Text style={styles.inputLabel}>Home Price ($)</Text>
          <TextInput
            style={styles.textInput}
            value={mortgageData.homePrice}
            onChangeText={(text) => setMortgageData({ ...mortgageData, homePrice: text })}
            keyboardType="numeric"
            placeholder="0"
          />
        </View>
        <View style={styles.inputContainer}>
          <Text style={styles.inputLabel}>Down Payment (%)</Text>
          <TextInput
            style={styles.textInput}
            value={mortgageData.downPaymentPercent}
            onChangeText={(text) => setMortgageData({ ...mortgageData, downPaymentPercent: text })}
            keyboardType="numeric"
            placeholder="0"
          />
        </View>
      </View>
      <View style={styles.inputRow}>
        <View style={styles.inputContainer}>
          <Text style={styles.inputLabel}>Loan Term (years)</Text>
          <TextInput
            style={styles.textInput}
            value={mortgageData.loanTerm}
            onChangeText={(text) => setMortgageData({ ...mortgageData, loanTerm: text })}
            keyboardType="numeric"
            placeholder="0"
          />
        </View>
        <View style={styles.inputContainer}>
          <Text style={styles.inputLabel}>Interest Rate (%)</Text>
          <TextInput
            style={styles.textInput}
            value={mortgageData.interestRate}
            onChangeText={(text) => setMortgageData({ ...mortgageData, interestRate: text })}
            keyboardType="numeric"
            placeholder="0"
          />
        </View>
      </View>
    </View>
  );

  const renderLoanCalculator = () => (
    <View style={styles.calculatorContainer}>
      <Text style={styles.calculatorTitle}>Loan Calculator</Text>
      <View style={styles.inputRow}>
        <View style={styles.inputContainer}>
          <Text style={styles.inputLabel}>Loan Amount ($)</Text>
          <TextInput
            style={styles.textInput}
            value={loanData.loanAmount}
            onChangeText={(text) => setLoanData({ ...loanData, loanAmount: text })}
            keyboardType="numeric"
            placeholder="0"
          />
        </View>
        <View style={styles.inputContainer}>
          <Text style={styles.inputLabel}>Loan Term (years)</Text>
          <TextInput
            style={styles.textInput}
            value={loanData.loanTerm}
            onChangeText={(text) => setLoanData({ ...loanData, loanTerm: text })}
            keyboardType="numeric"
            placeholder="0"
          />
        </View>
      </View>
      <View style={styles.inputContainer}>
        <Text style={styles.inputLabel}>Interest Rate (%)</Text>
        <TextInput
          style={styles.textInput}
          value={loanData.interestRate}
          onChangeText={(text) => setLoanData({ ...loanData, interestRate: text })}
          keyboardType="numeric"
          placeholder="0"
        />
      </View>
    </View>
  );

  const renderResults = () => {
    if (!results) return null;

    return (
      <View style={styles.resultsContainer}>
        <Text style={styles.resultsTitle}>Calculation Results</Text>
        <View style={styles.resultsGrid}>
          {results.futureValue !== undefined && (
            <View style={[styles.resultCard, { backgroundColor: '#10B98120' }]}>
              <Text style={styles.resultLabel}>Future Value</Text>
              <Text style={[styles.resultValue, { color: '#10B981' }]}>
                {formatCurrency(results.futureValue)}
              </Text>
            </View>
          )}
          {results.totalContributions !== undefined && (
            <View style={[styles.resultCard, { backgroundColor: '#3B82F620' }]}>
              <Text style={styles.resultLabel}>Total Contributions</Text>
              <Text style={[styles.resultValue, { color: '#3B82F6' }]}>
                {formatCurrency(results.totalContributions)}
              </Text>
            </View>
          )}
          {results.totalInterest !== undefined && (
            <View style={[styles.resultCard, { backgroundColor: '#8B5CF620' }]}>
              <Text style={styles.resultLabel}>Total Interest</Text>
              <Text style={[styles.resultValue, { color: '#8B5CF6' }]}>
                {formatCurrency(results.totalInterest)}
              </Text>
            </View>
          )}
          {results.monthlyPayment !== undefined && (
            <View style={[styles.resultCard, { backgroundColor: '#F59E0B20' }]}>
              <Text style={styles.resultLabel}>Monthly Payment</Text>
              <Text style={[styles.resultValue, { color: '#F59E0B' }]}>
                {formatCurrency(results.monthlyPayment)}
              </Text>
            </View>
          )}
          {results.totalAmountPaid !== undefined && (
            <View style={[styles.resultCard, { backgroundColor: '#EF444420' }]}>
              <Text style={styles.resultLabel}>Total Amount Paid</Text>
              <Text style={[styles.resultValue, { color: '#EF4444' }]}>
                {formatCurrency(results.totalAmountPaid)}
              </Text>
            </View>
          )}
          {results.monthlyIncome !== undefined && (
            <View style={[styles.resultCard, { backgroundColor: '#10B98120' }]}>
              <Text style={styles.resultLabel}>Monthly Income at Retirement</Text>
              <Text style={[styles.resultValue, { color: '#10B981' }]}>
                {formatCurrency(results.monthlyIncome)}
              </Text>
            </View>
          )}
        </View>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Financial Calculators</Text>
      </View>
      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {renderCalculatorSelector()}
        
        {selectedCalculator === 'interest' && renderInterestCalculator()}
        {selectedCalculator === 'roth-ira' && renderRothIRACalculator()}
        {selectedCalculator === 'mortgage' && renderMortgageCalculator()}
        {selectedCalculator === 'loan' && renderLoanCalculator()}

        <TouchableOpacity style={styles.calculateButton} onPress={handleCalculate}>
          <Ionicons name="calculator" size={20} color="#FFFFFF" />
          <Text style={styles.calculateButtonText}>Calculate</Text>
        </TouchableOpacity>

        {renderResults()}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    padding: 16,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  title: {
    fontSize: 20,
    fontWeight: '600',
    color: '#1F2937',
  },
  scrollView: {
    flex: 1,
  },
  selectorContainer: {
    padding: 16,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  selectorTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1F2937',
    marginBottom: 12,
  },
  selectorScroll: {
    flexDirection: 'row',
  },
  selectorOption: {
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginRight: 12,
    borderRadius: 12,
    backgroundColor: '#F3F4F6',
    minWidth: 120,
  },
  selectorOptionSelected: {
    backgroundColor: '#3B82F6',
  },
  selectorOptionText: {
    fontSize: 12,
    fontWeight: '500',
    color: '#6B7280',
    marginTop: 4,
    textAlign: 'center',
  },
  selectorOptionTextSelected: {
    color: '#FFFFFF',
  },
  calculatorContainer: {
    padding: 16,
    backgroundColor: '#FFFFFF',
    margin: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  calculatorTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1F2937',
    marginBottom: 16,
  },
  inputRow: {
    flexDirection: 'row',
    gap: 12,
  },
  inputContainer: {
    flex: 1,
    marginBottom: 16,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: '500',
    color: '#1F2937',
    marginBottom: 6,
  },
  textInput: {
    borderWidth: 1,
    borderColor: '#D1D5DB',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    color: '#1F2937',
    backgroundColor: '#FFFFFF',
  },
  calculateButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#3B82F6',
    paddingVertical: 16,
    borderRadius: 12,
    margin: 16,
    gap: 8,
  },
  calculateButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  resultsContainer: {
    padding: 16,
    backgroundColor: '#FFFFFF',
    margin: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  resultsTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1F2937',
    marginBottom: 16,
  },
  resultsGrid: {
    gap: 12,
  },
  resultCard: {
    padding: 16,
    borderRadius: 8,
  },
  resultLabel: {
    fontSize: 14,
    color: '#6B7280',
    marginBottom: 4,
  },
  resultValue: {
    fontSize: 20,
    fontWeight: '600',
  },
});