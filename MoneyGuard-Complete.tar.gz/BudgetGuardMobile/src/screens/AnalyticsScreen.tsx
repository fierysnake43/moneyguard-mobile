import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  RefreshControl,
  ActivityIndicator,
  Dimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { apiService, DashboardData, Transaction, BudgetCategory } from '../services/api';

const { width } = Dimensions.get('window');

export default function AnalyticsScreen() {
  const [dashboardData, setDashboardData] = useState<DashboardData | null>(null);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [categories, setCategories] = useState<BudgetCategory[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [dashboardResponse, transactionsResponse, categoriesResponse] = await Promise.all([
        apiService.getDashboard(),
        apiService.getTransactions(),
        apiService.getBudgetCategories(),
      ]);
      setDashboardData(dashboardResponse);
      setTransactions(transactionsResponse);
      setCategories(categoriesResponse);
    } catch (error) {
      console.error('Error loading data:', error);
      Alert.alert('Error', 'Failed to load analytics data');
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  const getSpendingTrend = () => {
    const thisMonth = new Date().getMonth();
    const currentMonthTransactions = transactions.filter(t => {
      const transactionMonth = new Date(t.date).getMonth();
      return transactionMonth === thisMonth;
    });
    
    const totalSpent = currentMonthTransactions.reduce((sum, t) => sum + parseFloat(t.amount), 0);
    const daysInMonth = new Date(new Date().getFullYear(), thisMonth + 1, 0).getDate();
    const currentDay = new Date().getDate();
    const dailyAverage = totalSpent / currentDay;
    const projectedSpending = dailyAverage * daysInMonth;
    
    return {
      totalSpent,
      dailyAverage,
      projectedSpending,
      daysRemaining: daysInMonth - currentDay,
    };
  };

  const getCategoryInsights = () => {
    return categories.map(category => {
      const categoryTransactions = transactions.filter(t => t.categoryId === category.id);
      const totalSpent = categoryTransactions.reduce((sum, t) => sum + parseFloat(t.amount), 0);
      const limit = parseFloat(category.limit);
      const remaining = limit - totalSpent;
      const daysInMonth = new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0).getDate();
      const currentDay = new Date().getDate();
      const daysRemaining = daysInMonth - currentDay;
      const dailyAllowance = remaining / Math.max(daysRemaining, 1);
      
      return {
        ...category,
        totalSpent,
        remaining,
        dailyAllowance,
        daysRemaining,
        utilization: (totalSpent / limit) * 100,
      };
    });
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'Need':
        return '#3B82F6';
      case 'Want':
        return '#8B5CF6';
      case 'Investing':
        return '#10B981';
      default:
        return '#6B7280';
    }
  };

  const spendingTrend = getSpendingTrend();
  const categoryInsights = getCategoryInsights();

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#3B82F6" />
        <Text style={styles.loadingText}>Loading...</Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Analytics</Text>
        <Text style={styles.subtitle}>Spending insights and trends</Text>
      </View>
      
      <ScrollView
        style={styles.scrollView}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
        showsVerticalScrollIndicator={false}
      >
        {/* Spending Overview */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Monthly Overview</Text>
          <View style={styles.overviewCards}>
            <View style={[styles.overviewCard, { backgroundColor: '#3B82F620' }]}>
              <Text style={styles.overviewLabel}>Total Spent</Text>
              <Text style={[styles.overviewValue, { color: '#3B82F6' }]}>
                {formatCurrency(spendingTrend.totalSpent)}
              </Text>
            </View>
            <View style={[styles.overviewCard, { backgroundColor: '#10B98120' }]}>
              <Text style={styles.overviewLabel}>Daily Average</Text>
              <Text style={[styles.overviewValue, { color: '#10B981' }]}>
                {formatCurrency(spendingTrend.dailyAverage)}
              </Text>
            </View>
            <View style={[styles.overviewCard, { backgroundColor: '#F59E0B20' }]}>
              <Text style={styles.overviewLabel}>Projected Total</Text>
              <Text style={[styles.overviewValue, { color: '#F59E0B' }]}>
                {formatCurrency(spendingTrend.projectedSpending)}
              </Text>
            </View>
          </View>
        </View>

        {/* Budget Progress */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Budget Progress</Text>
          {dashboardData?.categoryProgress && dashboardData.categoryProgress.length > 0 ? (
            <View style={styles.progressContainer}>
              {dashboardData.categoryProgress.map((category) => (
                <View key={category.id} style={styles.progressCard}>
                  <View style={styles.progressHeader}>
                    <Text style={styles.progressCategoryName}>{category.name}</Text>
                    <Text style={styles.progressPercentage}>
                      {Math.round(category.percentage)}%
                    </Text>
                  </View>
                  <View style={styles.progressBar}>
                    <View
                      style={[
                        styles.progressFill,
                        {
                          width: `${Math.min(category.percentage, 100)}%`,
                          backgroundColor: category.percentage > 100 ? '#EF4444' : 
                                         category.percentage > 80 ? '#F59E0B' : '#10B981',
                        },
                      ]}
                    />
                  </View>
                  <View style={styles.progressFooter}>
                    <Text style={styles.progressAmount}>
                      {formatCurrency(category.spent)} of {formatCurrency(parseFloat(category.limit))}
                    </Text>
                    <Text style={[
                      styles.progressStatus,
                      { color: category.percentage > 100 ? '#EF4444' : '#6B7280' }
                    ]}>
                      {category.status}
                    </Text>
                  </View>
                </View>
              ))}
            </View>
          ) : (
            <View style={styles.emptyState}>
              <Ionicons name="bar-chart-outline" size={32} color="#9CA3AF" />
              <Text style={styles.emptyText}>No budget data available</Text>
            </View>
          )}
        </View>

        {/* Daily Spending Allowance */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Daily Spending Allowance</Text>
          <Text style={styles.sectionSubtitle}>
            Remaining budget divided by days left in month
          </Text>
          {categoryInsights.length > 0 ? (
            <View style={styles.allowanceContainer}>
              {categoryInsights.map((category) => (
                <View key={category.id} style={styles.allowanceCard}>
                  <View style={styles.allowanceHeader}>
                    <View style={styles.allowanceIcon}>
                      <Ionicons name="calendar-outline" size={16} color={getTypeColor(category.type)} />
                    </View>
                    <Text style={styles.allowanceCategoryName}>{category.name}</Text>
                  </View>
                  <View style={styles.allowanceContent}>
                    <Text style={styles.allowanceAmount}>
                      {category.remaining > 0 
                        ? formatCurrency(category.dailyAllowance) 
                        : formatCurrency(0)
                      }
                    </Text>
                    <Text style={styles.allowanceLabel}>per day</Text>
                  </View>
                  <Text style={styles.allowanceDays}>
                    {category.daysRemaining} days remaining
                  </Text>
                  {category.remaining <= 0 && (
                    <Text style={styles.allowanceWarning}>
                      Budget exceeded
                    </Text>
                  )}
                </View>
              ))}
            </View>
          ) : (
            <View style={styles.emptyState}>
              <Ionicons name="calendar-outline" size={32} color="#9CA3AF" />
              <Text style={styles.emptyText}>No categories to analyze</Text>
            </View>
          )}
        </View>

        {/* Category Breakdown */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Category Breakdown</Text>
          {categoryInsights.length > 0 ? (
            <View style={styles.breakdownContainer}>
              {categoryInsights.map((category) => (
                <View key={category.id} style={styles.breakdownCard}>
                  <View style={styles.breakdownHeader}>
                    <View style={[styles.breakdownIcon, { backgroundColor: `${getTypeColor(category.type)}20` }]}>
                      <Ionicons name="card-outline" size={16} color={getTypeColor(category.type)} />
                    </View>
                    <View style={styles.breakdownInfo}>
                      <Text style={styles.breakdownCategoryName}>{category.name}</Text>
                      <Text style={styles.breakdownType}>{category.type}</Text>
                    </View>
                    <Text style={styles.breakdownAmount}>
                      {formatCurrency(category.totalSpent)}
                    </Text>
                  </View>
                  <View style={styles.breakdownStats}>
                    <View style={styles.breakdownStat}>
                      <Text style={styles.breakdownStatValue}>
                        {Math.round(category.utilization)}%
                      </Text>
                      <Text style={styles.breakdownStatLabel}>Utilized</Text>
                    </View>
                    <View style={styles.breakdownStat}>
                      <Text style={[
                        styles.breakdownStatValue,
                        { color: category.remaining >= 0 ? '#10B981' : '#EF4444' }
                      ]}>
                        {formatCurrency(Math.abs(category.remaining))}
                      </Text>
                      <Text style={styles.breakdownStatLabel}>
                        {category.remaining >= 0 ? 'Remaining' : 'Over Budget'}
                      </Text>
                    </View>
                  </View>
                </View>
              ))}
            </View>
          ) : (
            <View style={styles.emptyState}>
              <Ionicons name="pie-chart-outline" size={32} color="#9CA3AF" />
              <Text style={styles.emptyText}>No spending data available</Text>
            </View>
          )}
        </View>

        {/* Recommendations */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Recommendations</Text>
          <View style={styles.recommendationsContainer}>
            {spendingTrend.projectedSpending > (dashboardData?.totalBudget || 0) && (
              <View style={styles.recommendationCard}>
                <View style={styles.recommendationIcon}>
                  <Ionicons name="warning" size={16} color="#F59E0B" />
                </View>
                <View style={styles.recommendationContent}>
                  <Text style={styles.recommendationTitle}>Budget Alert</Text>
                  <Text style={styles.recommendationText}>
                    Your projected spending exceeds your total budget. Consider reducing expenses in overspent categories.
                  </Text>
                </View>
              </View>
            )}
            
            {categoryInsights.some(c => c.utilization > 80) && (
              <View style={styles.recommendationCard}>
                <View style={styles.recommendationIcon}>
                  <Ionicons name="speedometer" size={16} color="#EF4444" />
                </View>
                <View style={styles.recommendationContent}>
                  <Text style={styles.recommendationTitle}>High Utilization</Text>
                  <Text style={styles.recommendationText}>
                    Some categories are close to their limits. Monitor spending carefully to avoid overages.
                  </Text>
                </View>
              </View>
            )}
            
            {spendingTrend.daysRemaining > 0 && spendingTrend.dailyAverage > 0 && (
              <View style={styles.recommendationCard}>
                <View style={styles.recommendationIcon}>
                  <Ionicons name="trending-up" size={16} color="#10B981" />
                </View>
                <View style={styles.recommendationContent}>
                  <Text style={styles.recommendationTitle}>Spending Pace</Text>
                  <Text style={styles.recommendationText}>
                    You're spending {formatCurrency(spendingTrend.dailyAverage)} per day on average. 
                    Track your progress to stay within budget.
                  </Text>
                </View>
              </View>
            )}
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: '#6B7280',
  },
  header: {
    padding: 16,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  title: {
    fontSize: 20,
    fontWeight: '600',
    color: '#1F2937',
  },
  subtitle: {
    fontSize: 14,
    color: '#6B7280',
    marginTop: 4,
  },
  scrollView: {
    flex: 1,
  },
  section: {
    padding: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1F2937',
    marginBottom: 4,
  },
  sectionSubtitle: {
    fontSize: 14,
    color: '#6B7280',
    marginBottom: 16,
  },
  overviewCards: {
    flexDirection: 'row',
    gap: 12,
  },
  overviewCard: {
    flex: 1,
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  overviewLabel: {
    fontSize: 12,
    color: '#6B7280',
    marginBottom: 4,
  },
  overviewValue: {
    fontSize: 16,
    fontWeight: '600',
  },
  progressContainer: {
    gap: 12,
  },
  progressCard: {
    backgroundColor: '#FFFFFF',
    padding: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  progressHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  progressCategoryName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1F2937',
  },
  progressPercentage: {
    fontSize: 14,
    fontWeight: '600',
    color: '#6B7280',
  },
  progressBar: {
    height: 8,
    backgroundColor: '#F3F4F6',
    borderRadius: 4,
    overflow: 'hidden',
    marginBottom: 8,
  },
  progressFill: {
    height: '100%',
    borderRadius: 4,
  },
  progressFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  progressAmount: {
    fontSize: 14,
    color: '#6B7280',
  },
  progressStatus: {
    fontSize: 12,
    fontWeight: '500',
  },
  allowanceContainer: {
    gap: 12,
  },
  allowanceCard: {
    backgroundColor: '#FFFFFF',
    padding: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  allowanceHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  allowanceIcon: {
    width: 24,
    height: 24,
    borderRadius: 4,
    backgroundColor: '#F3F4F6',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 8,
  },
  allowanceCategoryName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1F2937',
  },
  allowanceContent: {
    alignItems: 'center',
    marginBottom: 8,
  },
  allowanceAmount: {
    fontSize: 24,
    fontWeight: '700',
    color: '#1F2937',
  },
  allowanceLabel: {
    fontSize: 14,
    color: '#6B7280',
  },
  allowanceDays: {
    fontSize: 12,
    color: '#6B7280',
    textAlign: 'center',
  },
  allowanceWarning: {
    fontSize: 12,
    color: '#EF4444',
    textAlign: 'center',
    marginTop: 4,
    fontWeight: '500',
  },
  breakdownContainer: {
    gap: 12,
  },
  breakdownCard: {
    backgroundColor: '#FFFFFF',
    padding: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  breakdownHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  breakdownIcon: {
    width: 32,
    height: 32,
    borderRadius: 6,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  breakdownInfo: {
    flex: 1,
  },
  breakdownCategoryName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1F2937',
  },
  breakdownType: {
    fontSize: 12,
    color: '#6B7280',
  },
  breakdownAmount: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1F2937',
  },
  breakdownStats: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#F3F4F6',
  },
  breakdownStat: {
    alignItems: 'center',
  },
  breakdownStatValue: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1F2937',
  },
  breakdownStatLabel: {
    fontSize: 12,
    color: '#6B7280',
    marginTop: 2,
  },
  recommendationsContainer: {
    gap: 12,
  },
  recommendationCard: {
    flexDirection: 'row',
    backgroundColor: '#FFFFFF',
    padding: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  recommendationIcon: {
    width: 32,
    height: 32,
    borderRadius: 6,
    backgroundColor: '#F3F4F6',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  recommendationContent: {
    flex: 1,
  },
  recommendationTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1F2937',
    marginBottom: 4,
  },
  recommendationText: {
    fontSize: 14,
    color: '#6B7280',
    lineHeight: 20,
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 32,
  },
  emptyText: {
    fontSize: 14,
    color: '#6B7280',
    marginTop: 8,
  },
});