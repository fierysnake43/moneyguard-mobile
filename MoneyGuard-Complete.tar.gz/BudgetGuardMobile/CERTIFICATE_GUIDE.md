# Apple Certificates & App Store Connect Setup

## Good News: EAS Handles Certificates Automatically!

**You don't need to manually create certificates.** EAS (Expo Application Services) automatically handles all certificate creation and management for you.

## Your Configuration (Updated)
- **Apple ID**: joelascious1@icloud.com
- **Team ID**: AW4XQTS3RZ
- **Bundle ID**: com.budgetguard.mobile

## Certificate Process with EAS

### What EAS Does Automatically:
1. **Distribution Certificate** - Creates and manages
2. **Provisioning Profile** - Creates and manages
3. **App Store Connect API Key** - Handles authentication
4. **Code Signing** - Signs your app automatically
5. **Certificate Renewal** - Updates certificates when needed

### What You Need to Do:

#### 1. Create App in App Store Connect (No certificates needed first)
1. Go to [App Store Connect](https://appstoreconnect.apple.com/)
2. Sign in with joelascious1@icloud.com
3. Click **"My Apps"** → **"+"** → **"New App"**
4. Fill in:
   - **Name**: BudgetGuard
   - **Primary Language**: English (US)
   - **Bundle ID**: com.budgetguard.mobile
   - **SKU**: budgetguard-mobile-v1
   - **User Access**: Full Access

#### 2. Run Build Commands (EAS creates certificates during build)
```bash
cd mobile/BudgetGuardMobile
npm install -g eas-cli
eas login
# Use: joelascious1@icloud.com and your password
eas build:configure
eas build --platform ios --profile production
```

**During the build process, EAS will:**
- Ask for permission to create certificates
- Generate distribution certificate
- Create provisioning profile
- Register your app with Apple
- Sign your app automatically

#### 3. Submit to App Store
```bash
eas submit --platform ios --latest
```

## Why EAS is Better Than Manual Certificates

### Traditional Manual Process (Complex):
1. Create Certificate Signing Request (CSR)
2. Generate Distribution Certificate
3. Create App ID
4. Create Provisioning Profile
5. Download and install certificates
6. Configure Xcode
7. Build and archive
8. Upload to App Store Connect

### EAS Automated Process (Simple):
1. Run `eas build`
2. Approve certificate creation
3. EAS handles everything else
4. Submit with `eas submit`

## What Happens During Your First Build

### EAS Will Ask:
- "Generate a new Apple Distribution Certificate?" → **Yes**
- "Generate a new Apple Provisioning Profile?" → **Yes**
- "Would you like to automatically create an App Store Connect record?" → **Yes**

### You'll Need to Provide:
- Apple ID password (joelascious1@icloud.com)
- Two-factor authentication code (if enabled)
- Permission to create certificates

## Common Questions

**Q: Do I need Xcode?**
A: No, EAS builds in the cloud with Xcode 16.1 (iOS 18 SDK)

**Q: Do I need a Mac?**
A: No, EAS builds work from any computer

**Q: What about certificate expiration?**
A: EAS automatically renews certificates before expiration

**Q: Can I use existing certificates?**
A: Yes, but EAS automatic management is recommended

## Your Next Steps

1. **Create app in App Store Connect** (no certificates needed)
2. **Run build commands** (EAS creates certificates automatically)
3. **Submit to App Store** (EAS handles submission)

The certificate process is completely automated with EAS!