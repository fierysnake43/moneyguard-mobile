# Bundle ID Registration for BudgetGuard

## The Issue
You need to register your Bundle ID (com.budgetguard.mobile) with Apple before it appears in App Store Connect.

## Solution 1: Register Bundle ID Manually (Fastest)

### Step 1: Register Bundle ID in Apple Developer Portal
1. Go to [Apple Developer Portal](https://developer.apple.com/account/)
2. Sign in with joelascious1@icloud.com
3. Click **"Certificates, Identifiers & Profiles"**
4. Click **"Identifiers"** → **"+"** (Add new)
5. Select **"App IDs"** → **"Continue"**
6. Fill in:
   - **Description**: BudgetGuard Mobile App
   - **Bundle ID**: Explicit → `com.budgetguard.mobile`
   - **Capabilities**: Leave default (or add any needed like Push Notifications)
7. Click **"Continue"** → **"Register"**

### Step 2: Now Create App in App Store Connect
1. Go to [App Store Connect](https://appstoreconnect.apple.com/)
2. Sign in with joelascious1@icloud.com
3. Click **"My Apps"** → **"+"** → **"New App"**
4. Now you'll see **com.budgetguard.mobile** in the Bundle ID dropdown
5. Fill in:
   - **Name**: BudgetGuard
   - **Primary Language**: English (US)
   - **Bundle ID**: com.budgetguard.mobile (now available)
   - **SKU**: budgetguard-mobile-v1

## Solution 2: Use EAS to Register Bundle ID (Alternative)

### Commands to Run in Your Terminal:
```bash
cd mobile/BudgetGuardMobile
npm install -g eas-cli
eas login
# Enter: joelascious1@icloud.com and your password
eas build:configure
```

The `eas build:configure` command will:
- Register your Bundle ID with Apple
- Create necessary certificates
- Set up provisioning profiles
- Make the Bundle ID available in App Store Connect

## What Happens During Bundle ID Registration

### Apple Developer Portal Creates:
1. **App ID**: com.budgetguard.mobile
2. **Development Certificate**: For testing
3. **Distribution Certificate**: For App Store
4. **Provisioning Profile**: Links certificates to app

### Then Available in App Store Connect:
- Bundle ID dropdown will show com.budgetguard.mobile
- You can create your app listing
- Ready for app submission

## Recommended Approach

**I recommend Solution 1 (Manual Registration)** because:
- Faster (2-3 minutes vs 10-15 minutes)
- No build needed yet
- Direct control over Bundle ID settings
- Can immediately create App Store Connect listing

After registering the Bundle ID manually, you can still use EAS for building and deployment.

## Your Next Steps

1. **Register Bundle ID** in Apple Developer Portal (Solution 1)
2. **Create App** in App Store Connect (now Bundle ID will be available)
3. **Run EAS build** to create production app
4. **Submit to App Store** using EAS

The Bundle ID registration is the missing piece - once that's done, everything else flows smoothly!