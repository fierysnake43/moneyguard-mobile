# MoneyGuard Deployment - Exact Steps

## ✅ Ready to Deploy

Your MoneyGuard app is configured and ready. Here are the exact commands to run:

## Step 1: Open Shell Tab in Replit

Click the **"Shell"** tab in Replit (next to Console), then run:

```bash
cd mobile/BudgetGuardMobile
```

## Step 2: Set Up iOS Credentials

```bash
npx eas credentials
```

**Interactive prompts - select these options:**
1. **Platform**: Select `ios`
2. **What would you like to do?**: Select `Set up a distribution certificate`
3. **Generate a new certificate**: Select `Yes`
4. **Apple Developer Account**: Enter `joelascious1@icloud.com`
5. **Password**: Enter your Apple ID password
6. **2FA Code**: Enter the code from your Apple device

## Step 3: Build MoneyGuard App

```bash
npx eas build --platform ios --profile production
```

This takes **15-20 minutes** and creates your MoneyGuard iOS app.

## Step 4: Submit to App Store

```bash
npx eas submit --platform ios --latest
```

This uploads to App Store Connect using your App ID: **6748765441**

## That's It!

Your MoneyGuard app will be ready for Apple review in about 20 minutes total.

**Monitor progress at**: https://expo.dev/accounts/jcundiff2/projects/moneyguard-mobile

**App Store Connect**: Your build will appear automatically