# BudgetGuard Deployment Commands

## Your Apple Developer Details
- **Apple ID**: joelascious1@icloud.com
- **Bundle ID**: com.budgetguard.mobile (configured)

## Step 1: EAS CLI Setup (Run these commands)

```bash
cd mobile/BudgetGuardMobile
npm install -g eas-cli
eas login
```

When prompted for login:
- **Email**: joelascious1@icloud.com
- **Password**: 1cheekYmonkeY!

## Step 2: Find Your Apple Team ID

1. Go to [Apple Developer Portal](https://developer.apple.com/account/)
2. Sign in with joelascious1@icloud.com
3. Look for "Team ID" in the membership section
4. Copy the 10-character Team ID (format: ABC123DEFG)

## Step 3: Update Team ID in eas.json

Replace "YOUR_TEAM_ID" in eas.json with your actual Team ID from Apple Developer Portal.

## Step 4: Build Commands (Run after steps 1-3)

```bash
eas build:configure
eas build --platform ios --profile production
```

The build will:
- Take 10-15 minutes
- Create production .ipa file
- Use iOS 18 SDK (required for 2025)
- Handle all certificates automatically

## Step 5: Submit to App Store

```bash
eas submit --platform ios --latest
```

This automatically submits your built app to App Store Connect.

## App Store Connect Setup

1. Go to [App Store Connect](https://appstoreconnect.apple.com/)
2. Sign in with joelascious1@icloud.com
3. Click "My Apps" → "+" → "New App"
4. Fill in:
   - **Name**: BudgetGuard
   - **Primary Language**: English (US)
   - **Bundle ID**: com.budgetguard.mobile
   - **SKU**: budgetguard-mobile-v1

## If You Need Help

I can help with:
- Creating privacy policy content
- Writing app descriptions
- Troubleshooting build errors
- Preparing screenshots
- App Store listing optimization

Your app is technically ready for deployment!